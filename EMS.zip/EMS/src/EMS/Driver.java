package EMS;

import java.util.Scanner;

public class Driver extends HomePage{
	
    public static void main(String[] args)
    {
    	HomePage.main(args);
    }
}
